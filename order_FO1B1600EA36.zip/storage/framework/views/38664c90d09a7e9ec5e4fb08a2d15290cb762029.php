<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-2 col-lg-2">
        <?php echo $__env->make('admin.pages.faqs.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-10 col-lg-10">
        <div class="card">
            <div class="card-header">Frequently Asked Questions (FAQs)</div>
            <div class="-body">
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Sort Order</th>
                            <th scope="col">Question</th>
                            <th scope="col">Answer</th>
                            <th scope="col" colspan="2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($faq->id); ?></td>
                            <td><?php echo e($faq->sort_order); ?></td>
                            <td><?php echo e($faq->question); ?></td>
                            <td><?php echo e($faq->answer); ?></td>
                            <td>
                                <a class="btn btn-primary" href="/admin/faqs/<?php echo e($faq->id); ?>/edit/">Edit</a>
                            </td>
                            <td>
                                <a class="btn btn-danger" href="/admin/faqs/delete/<?php echo e($faq->id); ?>">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5">
                                <?php echo e($list->links("pagination::bootstrap-4")); ?>

                            </td>
                        </tr>
                    </tbody>

                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>