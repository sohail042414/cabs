<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'UK Airport Cab Services')); ?></title>

    <!-- Scripts -->
    <!--
        <script src="<?php echo e(asset('taxi-park/jquery.js')); ?>" defer></script>
    <script src="<?php echo e(asset('taxi-park/jquery-migrate.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('taxi-park/js_composer_front.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('taxi-park/modernizr-2.6.2.min.js')); ?>" defer></script>-->
    <script src="<?php echo e(asset('taxi-park/pace.js')); ?>" defer>
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>">
    </script>
    <script src="<?php echo e(asset('taxi-park/map-style.js')); ?>" defer>
    </script>
    <script src="<?php echo e(asset('taxi-park/skrollr.min.js')); ?>" defer>
    </script>
    <script src="<?php echo e(asset('taxi-park/scripts.js')); ?>" defer>
    </script>
    <!--<script src="<?php echo e(asset('taxi-park/scripts_theme.js')); ?>" defer></script>-->
    <script src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>" defer></script>     
    <script src="<?php echo e(asset('taxi-park/plugins.min.js')); ?>" defer></script>
    <!---<script src="<?php echo e(asset('jquery-ui/jquery-ui-timepicker-addon.js')); ?>"></script>-->
   

    <!-- Fonts -->

    <link href="<?php echo e(asset('taxi-park/font.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/typcn.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/unycon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/inline.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/js_composer.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('taxi-park/admin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/dashicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/editor-style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/entypo.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/ie.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/linecons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/lnr.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/selectize.css')); ?>" rel="stylesheet">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet">
    <!--<link href="<?php echo e(asset('jquery-ui/jquery-ui-timepicker-addon.css')); ?>" rel="stylesheet">-->
    
    <!-- Styles -->
    <!--<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">-->
    <link href="<?php echo e(asset('taxi-park/bootstrap-grid.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/plugins.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('taxi-park/styles.css')); ?>" rel="stylesheet">

</head>

<body class="page-template-default page masthead-fixed full-width footer-widgets singular wpb-js-composer js-comp-ver-5.5.2 vc_responsive">

    <div id="preloader"></div>
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>

</html>