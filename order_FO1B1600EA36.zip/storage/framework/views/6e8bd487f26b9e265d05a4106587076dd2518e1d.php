<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('jquery-ui/jquery-1.11.1.min.js')); ?>" defer></script>  
<script src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>" defer></script>  
<script src="<?php echo e(asset('jquery-ui/jquery-ui-timepicker-addon.js')); ?>" defer></script>  

<link href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('jquery-ui/jquery-ui-timepicker-addon.css')); ?>" rel="stylesheet">
<?php echo $__env->make('geocode', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<section class="page-header">
    <div class="container">
      <ul class="breadcrumbs">
        <li class="home"><a href="/"><?php echo e(config('app.name', 'UK Airport Cabs')); ?></a></li>
        <li class="current"><a href="/get-taxi">// Get Taxi</a></li>
      </ul>
      <h1>Get Taxi</h1>
    </div>
  </section>

<section class="tx-section">
    <div class="container">
      <div class="tx-heading center">
        <h4>OUR OPERATORS ARE WAITING FOR YOUR CALL</h4>
        <h2><?php echo e(config('app.settings.phone', '')); ?></h2>
      </div>


      <div class="row">
        <div class="col-md-8 offset-md-2">
          <div class="search-block-box">
            <?php echo $__env->make('front.common.taxi_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php echo $__env->make('front.common.section_tarrif', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('front.common.section_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>