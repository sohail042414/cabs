<?php echo $__env->make('admin.common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php ($method = ($action =='create') ? 'POST' : 'PUT'); ?>
<?php ($action_url = ($action =='create') ? '/admin/faqs' : '/admin/faqs/'.$faq->id); ?>


<form method="POST" action="<?php echo e($action_url); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field($method)); ?>

    <div class="form-group">
        <label for="sort_order">Sort Order</label>
        <input name="sort_order" type="text" value="<?php echo e(old('sort_order',$faq->sort_order)); ?>" class="form-control" id="sort_order">
        <small id="emailHelp" class="form-text text-muted">It will be used to display question in FAQs page, starting
            from lowest number. </small>
    </div>

    <div class="form-group">
        <label for="question">Question</label>
        <input type="text" name="question" value="<?php echo e(old('question',$faq->question)); ?>" id="question" class="form-control">
    </div>
    <div class="form-group">
        <label for="answer">Answer</label>
        <textarea name="answer" id="answer" rows="6" style="resize:x;" class="form-control"><?php echo e(old('answer',$faq->answer)); ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>