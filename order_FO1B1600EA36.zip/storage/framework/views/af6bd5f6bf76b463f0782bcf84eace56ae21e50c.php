<section data-vc-full-width="true" data-vc-full-width-init="true" class="vc_section" style="position: relative; left: -43px; box-sizing: border-box; width: 1286px; padding-left: 43px; padding-right: 43px;">
    <div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding car-block"
        style="position: relative; left: -43px; box-sizing: border-box; width: 1286px;">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner ">

                <div class="wpb_wrapper">
                    <div class="car-right animation-block">
                        <img src="/images/car-big-side.png" class="full-width slideleft" alt="animation">
                    </div>
                </div>


            </div>
        </div>
    </div>
    <div class="vc_row-full-width vc_clearfix"></div>
    <div class="vc_row wpb_row vc_row-fluid">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner vc_custom_1495641431935">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-sm vc_hidden-xs">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="vc_empty_space" style="height: 75px"><span class="vc_empty_space_inner"></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="heading  heading-large align-left" id="like_sc_header_158449325">
                        <h4>For Drivers</h4>
                        <h2>Do You Want To Earn With Us?</h2>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="wpb_text_column wpb_content_element ">
                                        <div class="wpb_wrapper">
                                            <p>Quisque sollicitudin feugiat risus, eu
                                                posuere ex euismod eu. Phasellus hendrerit,
                                                massa efficitur dapibus pulvinar, sapien
                                                eros sodales ante, euismod aliquet nulla
                                                metus a mauris.</p>

                                        </div>
                                    </div>

                                    <div class="wpb_text_column wpb_content_element ">
                                        <div class="wpb_wrapper">
                                            <ul class="check two-col strong">
                                                <li>Luxury cars</li>
                                                <li>No fee</li>
                                                <li>Weekly payment</li>
                                                <li>Fixed price</li>
                                                <li>Good application</li>
                                                <li>Stable orders</li>
                                            </ul>

                                        </div>
                                    </div>
                                    <div class="vc_empty_space" style="height: 20px"><span class="vc_empty_space_inner"></span></div>
                                    <div class="btn-wrap align-left"><a href="" class="btn  btn-lg align-left">Become
                                            a Driver</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-6">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="vc_row wpb_row vc_row-fluid">
        <div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-sm vc_hidden-xs">
            <div class="vc_column-inner ">
                <div class="wpb_wrapper">
                    <div class="vc_empty_space" style="height: 140px"><span class="vc_empty_space_inner"></span></div>
                </div>
            </div>
        </div>
    </div>
</section>