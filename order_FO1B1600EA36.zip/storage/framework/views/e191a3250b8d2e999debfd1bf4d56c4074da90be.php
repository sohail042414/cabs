<?php echo $__env->make('admin.common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php ($method = ($action =='create') ? 'POST' : 'PUT'); ?>
<?php ($action_url = ($action =='create') ? '/admin/airports' : '/admin/airports/'.$airport->id); ?>

<?php echo $__env->make('geocode', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form method="POST" action="<?php echo e($action_url); ?>">
    
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field($method)); ?>

    <div id="geo-wrap">
        <div class="form-group">
            <label for="name">Name</label>
            <input name="name" type="text" value="<?php echo e(old('name',$airport->name)); ?>" class="form-control" id="airport-title">
            <small id="titleHelp" class="form-text text-muted">Used for display.</small>
        </div>

        <div class="form-group">
            <label for="key">Latitude</label>
            <input data-geo="lat" type="text" name="lat" value="<?php echo e(old('lat',$airport->lat)); ?>" id="airport-lat" class="form-control"> 
            <small id="keyHelp" class="form-text text-muted">This should be a valid latitude, max value is 9999.xxxxxxx very small change can be dangerous!</small>
        </div>
        <div class="form-group">
            <label for="lng">Longitude</label>
            <input data-geo="lng" type="text" name="lng" id="airport-lng"  class="form-control" value="<?php echo e(old('lng',$airport->lng)); ?>" >
            <small id="keyHelp" class="form-text text-muted">This should be a valid latitude, max value is 9999.xxxxxxx very small change can be dangerous!</small>    
        </div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>

<script type="text/javascript">
$(document).ready(function(){
    $("#airport-title").geocomplete({
        details: "#geo-wrap",
        detailsAttribute: "data-geo",
        componentRestrictions : {'country': ['uk']}
    });
});

</script>