<?php $__env->startSection('content'); ?>
<section class="page-header">
    <div class="container">
      <ul class="breadcrumbs">
        <li class="home">
          <a href="/"><?php echo e(config('app.name', 'UK Airport Cabs')); ?></a>
        </li>
        <li class="current">
          <a href="/tarrif">// Tarrif</a>
        </li>
      </ul>
      <h1>Tarrif</h1>
    </div>
  </section>
<?php echo $__env->make('front.common.section_tarrif', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>