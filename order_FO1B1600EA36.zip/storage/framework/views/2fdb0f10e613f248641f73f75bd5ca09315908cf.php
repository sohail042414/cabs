<ul id="menu-main-menu" class="nav navbar-nav">
    <li id="menu-item-42" class="menu-item current-menu-parent">
        <a href="<?php echo e(url('/')); ?>/"><span>Home</span></a>
    </li>
    <li id="menu-item-50" class="menu-item">
        <a href="<?php echo e(url('/')); ?>/tarrif/"><span>Tarrif</span></a>
    </li>
    <li id="menu-item-50" class="menu-item">
        <a href="<?php echo e(url('/')); ?>/get-taxi/"><span>Get Taxi</span></a>
    </li>
    <li id="menu-item-55" class="menu-item">
        <a href="<?php echo e(url('/')); ?>/questions-answers/"><span>Q&A</span></a>
    </li>
    <li id="menu-item-59" class="menu-item">
        <a href="<?php echo e(url('/')); ?>/terms-conditions/"><span>T&C</span></a>
    </li>
    <li id="menu-item-707" class="menu-item">
        <a href="<?php echo e(url('/')); ?>/contact-us"><span>Contact Us</span></a>
    </li>
</ul>