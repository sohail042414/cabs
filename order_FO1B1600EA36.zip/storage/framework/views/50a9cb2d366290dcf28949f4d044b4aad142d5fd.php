<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-6 offset-md-3">
    <div class="login-wrapper">
        <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo e(csrf_field()); ?>

            <div class="login-header">
            <h1 class="lo-title">Login</h1>
            <span class="lo-sub"></span>
            </div>

            <div class="login-txt-block">
                <label>Email </label>
                <input type="email" name="email" placeholder="john@example.com" value="<?php echo e(old('email')); ?>" />
                <?php if($errors->has('email')): ?>
                <span class="error-message">  
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="login-txt-block">
                <label>Password</label>
                <input type="password" name="password" placeholder="*****" value="<?php echo e(old('password')); ?>" />
                <?php if($errors->has('password')): ?>
                <span class="error-message">  
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
                <?php endif; ?>
            </div>            
            <div class="login-txt-block">
                <button class="login-btn"> Login</button>
                <a href="/register" class="forgot">Register</a>
            </div>
        </form>
    </div>
    
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.auth_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>