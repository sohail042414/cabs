<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2 col-lg-2">
            <?php echo $__env->make('admin.pages.tarrifs.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-10 col-lg-10">
            <div class="card">
                <div class="card-header">Create Tarrif</div>

                <div class="card-body">
                    <?php echo $__env->make('admin.pages.tarrifs.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>