<?php $__env->startSection('content'); ?>

<section class="page-header">
    <div class="container">
      <ul class="breadcrumbs">
      <li class="home"><a href="/"><?php echo e(config('app.name', 'UK Airport Cabs')); ?></a></li>
        <li class="current"><a href="/terms-conditions">// Terms</a></li>
      </ul>
      <h1>Terms and conditions</h1>
    </div>
  </section>


  <section class="tx-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="tx-heading">
                        <h4>Terms and conditions</h4>
                        <!-- <h2>Terms and conditions</h2> -->
                        <!-- <p>Nam eu mi eget velit vulputate tempor gravida quis massa. In malesuada condimentum ultrices. Sed et mauris a purus fermentum elementum. Sed tristique semper enim, et gravida orci iaculis et. Nulla facilisi.</p> -->
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                   <Div class="terms-block">
                       <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <h2><?php echo e($term->title); ?></h2>
                      <div><?php echo $term->text; ?></div>
                      <hr>                             
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                     
                   </Div>

                </div>
            </div>

        </div>
  </section>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>