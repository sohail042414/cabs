<?php echo $__env->make('admin.common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php ($method = ($action =='create') ? 'POST' : 'PUT'); ?>
<?php ($action_url = ($action =='create') ? '/admin/tarrifs' : '/admin/tarrifs/'.$car_type->id); ?>


<form method="POST" action="<?php echo e($action_url); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field($method)); ?>


    <div class="form-group">
        <label for="car_type">Car Type</label>
        <select name="type" id="type" class="form-control">
            <option value="">Select</option>
            <?php $__currentLoopData = $type_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($type == old('type') || ($type == $car_type->type)): ?>
            <option selected="selected" value="<?php echo e($type); ?>"> <?php echo e($title); ?> </option>
            <?php else: ?>
            <option value="<?php echo e($type); ?>"> <?php echo e($title); ?> </option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="title">Title</label>
        <input name="title" type="text" value="<?php echo e(old('title',$car_type->title)); ?>" class="form-control"
            id="title">
        <small id="emailHelp" class="form-text text-muted"> </small>
    </div>

    <div class="form-group">
        <label for="description">Description</label>
        <textarea class="form-control" name="description" id="description"><?php echo e(old('description',$car_type->description)); ?></textarea>  
        <small id="emailHelp" class="form-text text-muted"> </small>
    </div>

    <div class="form-group">
        <label for="rate">Rate</label>
        <input type="text" name="rate" value="<?php echo e(old('rate',$car_type->rate)); ?>" id="rate" class="form-control">
    </div>
    <div class="form-group">
        <label for="capacity">Capacity (Number of persons)</label>
        <input type="text" name="capacity" value="<?php echo e(old('capacity',$car_type->capacity)); ?>" id="rate" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>