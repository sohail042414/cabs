<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-2 col-lg-2">
        <?php echo $__env->make('admin.pages.terms.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-10 col-lg-10">
        <div class="card">
            <div class="card-header">Terms and Conditions (T&C)</div>
            <div class="-body">
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Sort Order</th>
                            <th scope="col">Title</th>
                            <th scope="col">Text</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($term->id); ?></td>
                            <td><?php echo e($term->sort_order); ?></td>
                            <td><?php echo e($term->title); ?></td>
                            <td><?php echo e($term->text); ?></td>
                            <td>
                                <a class="btn btn-primary" href="/admin/terms/<?php echo e($term->id); ?>/edit/">
                                    Edit
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5">
                                <?php echo e($list->links("pagination::bootstrap-4")); ?>

                            </td>
                        </tr>
                    </tbody>

                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>