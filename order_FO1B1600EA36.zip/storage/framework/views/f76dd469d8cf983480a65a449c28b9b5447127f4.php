<!doctype html>
<html lang="en">
<head>
<title><?php echo e(config('app.name', 'UK Airport Cabs')); ?></title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="<?php echo e(asset('theme/css/bootstrap/bootstrap.css')); ?>">
  <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' type='text/css'
    media='all' />
  <link rel="stylesheet" href="<?php echo e(asset('theme/css/style.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('theme/css/zoomslider.css')); ?>" />
   <!-- Resource jQuery -->
   <script src="<?php echo e(asset('theme/js/jquery-2.1.1.js')); ?>"></script>
   <script src="<?php echo e(asset('theme/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('theme/js/main.js')); ?>"></script> 
</head>
<body>
  <?php echo $__env->make('front.common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->make('front.common.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('front.common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
  <!--
  <div id="preloader"></div>
  <div class="pace  pace-inactive">
    <div class="pace-progress" data-progress-text="100%" data-progress="99" style="transform: translate3d(100%, 0px, 0px);">
    <div class="pace-progress-inner"></div>
  </div>

  <div class="pace-activity">
  </div>
  <div class="grid-loader">
    <div class="grid-item"></div>
    <div class="grid-item"></div>
    <div class="grid-item"></div><div class="grid-item"></div>
    <div class="grid-item"></div><div class="grid-item"></div></div>
  </div>
-->
</body>
</html>