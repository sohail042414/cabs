<section class="tariffs-wrap tx-section bg">
    <div class="container">
      <div class="tx-heading center">
        <h4>SEE OUR</h4>
        <h2>TARIFFS</h2>
      </div>

      <div class="row">
      <?php $__currentLoopData = $tarrifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarrif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php ($vip_class = ($tarrif->type =='vip') ? 'active' : ''); ?>
        <div class="col-md-3">
          <div class="tariffs-block <?php echo e($vip_class); ?>">
            <div class="image">
              <img src="/images/<?php echo e($tarrif->image); ?>" alt="tariff" />
            </div>
            <h4><?php echo e($tarrif->title); ?></h4>
            <p><?php echo e($tarrif->desription); ?></p>
            <div class="price"><?php echo e(config('app.settings.currency_symbol')); ?><?php echo e($tarrif->rate); ?> <span>/mi</span> </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

    </div>
  </section>
