<section data-vc-full-width="true" data-vc-full-width-init="true" data-vc-parallax="1.5" data-vc-parallax-image="/images/download-bg.jpg"
    class="vc_section download-block vc_custom_item2 vc_section-has-fill vc_general vc_parallax vc_parallax-content-moving bg-color-black bg-overlay-black download-block"
    style="position: relative; left: -43px; box-sizing: border-box; width: 1286px; padding-left: 43px; padding-right: 43px;">
    <div class="vc_row wpb_row vc_row-fluid">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner ">
                <div class="wpb_wrapper">
                    <div class="heading  heading-large align-center" id="like_sc_header_375910216">
                        <h4>Get More Benefits</h4>
                        <h2>Download The App</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="vc_row wpb_row vc_row-fluid">
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner ">
                <div class="wpb_wrapper">
                    <div class="vc_empty_space" style="height: 66px"><span class="vc_empty_space_inner"></span></div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-content-top vc_row-flex">
                        <div class="wpb_column vc_column_container vc_col-sm-2 vc_hidden-sm vc_hidden-xs">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="heading  header-rounded align-center" id="like_sc_header_962976669">
                                        <h5>01.</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-10">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="wpb_text_column wpb_content_element ">
                                        <div class="wpb_wrapper">
                                            <h5>Fast booking</h5>
                                            <p>Nam ac ligula congue, interdum enim sit
                                                amet, fermentum nisi.</p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-2 vc_hidden-sm vc_hidden-xs">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="heading  header-rounded align-center" id="like_sc_header_1098703100">
                                        <h5>02.</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-10">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="wpb_text_column wpb_content_element ">
                                        <div class="wpb_wrapper">
                                            <h5 class="yellow">Easy to use</h5>
                                            <p>Orci varius natoque penatibus et magnis dis
                                                parturient montes, nascetur ridiculus mus.</p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill">
            <div class="vc_column-inner vc_custom_item3">
                <div class="wpb_wrapper">
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="mob wpb_column vc_column_container vc_col-sm-12 vc_col-has-fill">
                            <div class="vc_column-inner vc_custom_1495291256271">
                                <div class="wpb_wrapper">
                                    <div class="vc_empty_space" style="height: 200px"><span class="vc_empty_space_inner"></span></div>

                                    <div class="wpb_single_image wpb_content_element vc_align_center  vc_custom_1495637123038">

                                        <figure class="wpb_wrapper vc_figure">
                                            <a href="#" target="_self" class="vc_single_image-wrapper   vc_box_border_grey"><img
                                                    width="150" height="50" src="/images/app-google-150x50.png" class="vc_single_image-img attachment-thumbnail"
                                                    alt=""></a>
                                        </figure>
                                    </div>

                                    <div class="wpb_single_image wpb_content_element vc_align_center">

                                        <figure class="wpb_wrapper vc_figure">
                                            <a href="#" target="_self" class="vc_single_image-wrapper   vc_box_border_grey"><img
                                                    width="150" height="53" src="/images/app-apple-150x53.png" class="vc_single_image-img attachment-thumbnail"
                                                    alt=""></a>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-4">
            <div class="vc_column-inner ">
                <div class="wpb_wrapper">
                    <div class="vc_empty_space" style="height: 66px"><span class="vc_empty_space_inner"></span></div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-10">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="wpb_text_column wpb_content_element ">
                                        <div class="wpb_wrapper">
                                            <h5 class="yellow" style="text-align: right;">GPS
                                                searching</h5>
                                            <p style="text-align: right;">Ut elementum
                                                tincidunt erat vel ornare. Suspendisse ac
                                                felis non diam pretium.</p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-2 vc_hidden-sm vc_hidden-xs">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="heading  header-rounded align-center" id="like_sc_header_1690462518">
                                        <h5>03.</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="vc_row wpb_row vc_inner vc_row-fluid">
                        <div class="wpb_column vc_column_container vc_col-sm-10">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="wpb_text_column wpb_content_element ">
                                        <div class="wpb_wrapper">
                                            <h5 class="yellow" style="text-align: right;">Bonuses
                                                for ride</h5>
                                            <p style="text-align: right;">Phasellus l et
                                                porta tortor dignissim at. Pellentesque
                                                gravida tortor at euismod mollis.</p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="wpb_column vc_column_container vc_col-sm-2 vc_hidden-sm vc_hidden-xs">
                            <div class="vc_column-inner ">
                                <div class="wpb_wrapper">
                                    <div class="heading  header-rounded align-center" id="like_sc_header_1536522614">
                                        <h5>04.</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="vc_parallax-inner skrollable skrollable-before" data-bottom-top="top: -50%;" data-top-bottom="top: 0%;"
        style="height: 150%; background-image: url(&quot;/images/download-bg.jpg&quot;); top: -50%;"></div>
</section>