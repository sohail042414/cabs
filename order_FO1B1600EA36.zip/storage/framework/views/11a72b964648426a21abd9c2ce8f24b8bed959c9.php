<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2 col-lg-2">
            <?php echo $__env->make('admin.pages.bookings.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-10 col-lg-10">
            <div class="card">
                <?php if(count($cabs) == 0): ?>
                <div class="alert alert-danger">
                    <strong>Error! &nbsp;</strong> There are not free cabs, All booked!
                </div>
                <?php endif; ?>
                <div class="card-header">Assign cab to booking.</div>

                <div class="card-body">
                <?php echo $__env->make('admin.common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
                    <form method="POST" action="<?php echo e(url('/admin/bookings/confirm/'.$booking->id)); ?>">
                        
                    <?php echo e(csrf_field()); ?>

                       
                        <div class="form-group">
                            <label for="cab_id">Select Cab</label>
                            <select name="cab_id" id="cab_id" class="form-control">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $cabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cab->id == old('cab_id') || $cab->id == $booking->cab_id): ?>)
                                <option selected="selected" value="<?php echo e($cab->id); ?>"> <?php echo e($cab->name." | ".$cab->reg_number." | ".$cab->model); ?> </option>
                                <?php else: ?>
                                <option value="<?php echo e($cab->id); ?>"> <?php echo e($cab->name." | ".$cab->reg_number." | ".$cab->model); ?> </option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>


                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>