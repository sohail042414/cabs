<section data-vc-full-width="true" data-vc-full-width-init="true" class="vc_section bg-color-theme_color taxi-form-full"
    style="position: relative; left: -43px; box-sizing: border-box; width: 1286px; padding-left: 43px; padding-right: 43px;">
    <div class="vc_row wpb_row vc_row-fluid">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner ">
                <div class="wpb_wrapper">
                    <div role="form" class="wpcf7" id="wpcf7-f470-p10-o1" lang="en-US" dir="ltr">
                        <div class="screen-reader-response"></div>
                        <?php echo $__env->make('common.form_get_taxi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>