<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2 col-lg-2">
            <?php echo $__env->make('admin.pages.bookings.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-10 col-lg-10">
            <div class="card">
                
                <div class="card-header">
                    Booking Details , Booking Id # <?php echo e($booking->id); ?>                    
                    <a class="btn btn-primary" href="/admin/bookings/assign/<?php echo e($booking->id); ?>" style="float:right;">Assign/Change Cab</a>                    
                </div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-6 col-sm-12">
                            <h2>Booking Details</h2>    
                                <table class="table">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th scope="col">Field</th>
                                            <th scope="col">Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                        <tr>
                                            <th scope="col">Created At </th>
                                            <th scope="col"><?php echo e(date('d/m/Y h:i',strtotime($booking->created_at))); ?></th>
                                        </tr>

                                        <?php $__currentLoopData = $booking->showBookingFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row"><?php echo e($data['title']); ?></td>
                                            <td><?php echo e($data['value']); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                        </div>

                        <div class="col-md-6 col-lg-6 col-sm-12">
                            <?php if($booking->status =='confirmed' && is_object($booking->cab)): ?>
                            <h2>Cab details</h2>    
                            <table class="table">    
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">Field</th>
                                        <th scope="col">Value</th>
                                    </tr>
                                </thead>  
                                <tbody>                      
                                    <?php $__currentLoopData = $booking->showCabFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row"><?php echo e($title); ?></td>
                                            <td><?php echo e($booking->cab->{$field}); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    </tbody>                        
                                </table>
                            <?php endif; ?>

                            <?php if($booking->status =='confirmed' && is_object($booking->driver)): ?>
                            <h2>Driver details</h2>    
                            <table class="table">    
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">Field</th>
                                        <th scope="col">Value</th>
                                    </tr>
                                </thead>  
                                <tbody>                      
                                    <?php $__currentLoopData = $booking->showDriverFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td scope="row"><?php echo e($title); ?></td>
                                            <td><?php echo e($booking->driver->{$field}); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                    </tbody>                        
                                </table>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>