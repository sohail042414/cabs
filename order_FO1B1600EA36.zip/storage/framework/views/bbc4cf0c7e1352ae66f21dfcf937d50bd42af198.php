<?php echo $__env->make('admin.common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php ($method = ($action =='create') ? 'POST' : 'PUT'); ?>
<?php ($action_url = ($action =='create') ? '/admin/cabs' : '/admin/cabs/'.$cab->id); ?>


<form method="POST" action="<?php echo e($action_url); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field($method)); ?>


    <div class="form-group">
        <label for="car_type">Car Type</label>
        <select name="type" id="type" class="form-control">
            <option value="">Select</option>
            <?php $__currentLoopData = $type_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($type == old('type') || ($type == $cab->type)): ?>
            <option selected="selected" value="<?php echo e($type); ?>"> <?php echo e($title); ?> </option>
            <?php else: ?>
            <option value="<?php echo e($type); ?>"> <?php echo e($title); ?> </option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="car_type">Status</label>
        <select name="status" id="type" class="form-control">
            <option value="">Select</option>
            <?php $__currentLoopData = $status_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($status == old('status') || ($status == $cab->status)): ?>
            <option selected="selected" value="<?php echo e($status); ?>"> <?php echo e($title); ?> </option>
            <?php else: ?>
            <option value="<?php echo e($status); ?>"> <?php echo e($title); ?> </option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="driver_id">Driver</label>
        <select name="driver_id" id="cab-driver-id" class="form-control">
            <option value="">Select</option>
            <?php $__currentLoopData = $drivers_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($driver->id == old('driver_id') || ($cab->driver_id == $driver->id)): ?>
            <option selected="selected" value="<?php echo e($driver->id); ?>"> <?php echo e($driver->name); ?> </option>
            <?php else: ?>
            <option value="<?php echo e($driver->id); ?>"> <?php echo e($driver->name); ?> </option>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="reg_number">Reg Number (Vehicle Numuber)</label>
        <input name="reg_number" type="text" value="<?php echo e(old('reg_number',$cab->reg_number)); ?>" class="form-control"
            id="title">
        <small id="emailHelp" class="form-text text-muted"> </small>
    </div>

    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" name="name" id="cab-name" value="<?php echo e(old('name',$cab->name)); ?>" > 
        <small id="emailHelp" class="form-text text-muted"> e.g. Accord, BMW X2</small>
    </div>

    <div class="form-group">
        <label for="name">Model</label>
        <input type="text" class="form-control" name="model" id="cab-model" value="<?php echo e(old('model',$cab->model)); ?>" > 
        <small id="emailHelp" class="form-text text-muted"> e.g. 2018, </small>
    </div>

    <div class="form-group">
        <label for="brand">Brand</label>
        <input type="text" class="form-control" name="brand" id="cab-brand" value="<?php echo e(old('brand',$cab->brand)); ?>" > 
        <small id="emailHelp" class="form-text text-muted">Optional,  e.g. Honda, BMW, Volkswagen  </small>
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>