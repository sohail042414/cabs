<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2 col-lg-2">
            <?php echo $__env->make('admin.pages.cabs.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-10 col-lg-10">
            <div class="card">
                <div class="card-header">Cabs</div>
                <div class="card-body">

                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Type(Key)</th>
                                <th scope="col">Name</th>
                                <th scope="col">Model</th>
                                <th scope="col">Reg#</th>
                                <th scope="col">Brand</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($cab->id); ?></th>
                                <td><?php echo e($cab->type); ?></td>
                                <td><?php echo e($cab->name); ?></td>
                                <td><?php echo e($cab->model); ?></td>
                                <td><?php echo e($cab->reg_number); ?></td>                                
                                <td><?php echo e($cab->brand); ?></td>
                                <td>
                                    <a class="btn btn-primary" href="/admin/cabs/<?php echo e($cab->id); ?>/edit/">
                                        Edit
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="5">
                                    <?php echo e($list->links("pagination::bootstrap-4")); ?>

                                </td>
                            </tr>
                        </tbody>

                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>