<section id="block-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6 col-ms-12  matchHeight clearfix" style="height: 308px;">
                <div class="footer-widget-area">
                    <div id="text-2" class="widget widget_text">
                        <h4>About Us</h4>
                        <div class="textwidget">Nullam orci dui, dictum et magna sollicitudin, tempor blandit erat.
                            Maecenas suscipit tellus sit amet augue placerat fringilla a id lacus. Fusce tincidunt
                            in leo lacinia condimentum. </div>
                    </div>
                    <div id="taxipark_icons-2" class="widget widget_taxipark_icons">
                        <ul class="social-small">
                            <li><a href="#" class="fa fa-twitter"></a></li>
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-pinterest-square"></a></li>
                            <li><a href="#" class="fa fa-skype"></a></li>
                            <li><a href="#" class="fa fa-google-plus"></a></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-5 col-sm-6 col-ms-12 hidden-xs hidden-ms hidden-sm matchHeight clearfix" style="height: 308px;">
                <div class="footer-widget-area">
                    <div id="nav_menu-2" class="widget widget_nav_menu">
                        <h4>Explore</h4>
                        <div class="menu-footer-menu-container">
                            <ul id="menu-footer-menu" class="menu">
                                <li id="menu-item-128" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-128"><a
                                        href="http://uktaxi.local/gallery-2-columns/">Gallery</a></li>
                                <li id="menu-item-129" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-129"><a
                                        href="http://uktaxi.local/contacts/">Contacts</a></li>
                                <li id="menu-item-130" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-130"><a
                                        href="http://uktaxi.local/testimonials/">Testimonials</a></li>
                                <li id="menu-item-131" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-131"><a
                                        href="http://uktaxi.local/blog-two-columns/">Blog</a></li>
                                <li id="menu-item-132" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-132"><a
                                        href="http://uktaxi.local/services/">Services</a></li>
                                <li id="menu-item-133" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-133"><a
                                        href="http://uktaxi.local/get-taxi/">Get Taxi</a></li>
                                <li id="menu-item-481" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-481"><a
                                        href="http://uktaxi.local/shortcodes/">Shortcodes</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-ms-12  matchHeight clearfix" style="height: 308px;">
                <div class="footer-widget-area">
                    <div id="text-3" class="widget widget_text">
                        <h4>Contact us</h4>
                        <div class="textwidget"><strong>Address:</strong> 43 2-nd Avenue, New York, NY 29004-7153</div>
                    </div>
                    <div id="taxipark_icons-3" class="widget widget_taxipark_icons">
                        <ul class="social-icons-list">
                            <li><a href="#"><span class="fa fa-phone"></span>800-5-800</a></li>
                            <li><a href="#"><span class="fa fa-envelope"></span>gettaxi@taxipark.co.uk</a></li>
                            <li><a href="#"><span class="fa fa-skype"></span>gettaxipark</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>