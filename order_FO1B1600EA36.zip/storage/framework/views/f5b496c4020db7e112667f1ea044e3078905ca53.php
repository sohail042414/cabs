<?php $__env->startSection('content'); ?>

<?php echo $__env->make('common.navbar_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<header class="page-header">
    <div class="container">
        <ul class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
        </ul>
        <h1>Earn With US</h1>
    </div>
</header>

<div class="container">
    <!-- Content -->
    <div class="margin-disabled">
        <div class="row">
            <div class=" col-md-12 text-page">
                <article id="post-25" class="post-25 page type-page status-publish hentry">
                    <div class="entry-content clearfix">
                        <?php echo $__env->make('common.section_partners', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="vc_row-full-width vc_clearfix"></div>
                        <?php echo $__env->make('common.zipper', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php echo $__env->make('common.section_testimonials', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </article>
            </div>

        </div>
    </div>

</div>



<?php echo $__env->make('common.section_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>