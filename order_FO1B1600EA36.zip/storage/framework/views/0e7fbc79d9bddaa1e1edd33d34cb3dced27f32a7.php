<nav>
    <ul class="cd-primary-nav">
        <li id="menu-item-42" class="menu-item current-menu-parent">
            <a href="<?php echo e(url('/')); ?>/"><span>Home</span></a>
        </li>
        <li id="menu-item-50" class="menu-item">
            <a href="<?php echo e(url('/')); ?>/tarrif/"><span>Tarrif</span></a>
        </li>
        <li id="menu-item-50" class="menu-item">
            <a href="<?php echo e(url('/')); ?>/get-taxi/"><span>Get Taxi</span></a>
        </li>
        <li id="menu-item-55" class="menu-item">
            <a href="<?php echo e(url('/')); ?>/questions-answers/"><span>Q&A</span></a>
        </li>
        <li id="menu-item-59" class="menu-item">
            <a href="<?php echo e(url('/')); ?>/terms-conditions/"><span>T&C</span></a>
        </li>        
        <li id="menu-item-707" class="menu-item">
            <a href="<?php echo e(url('/')); ?>/contact-us"><span>Contact Us</span></a>
        </li>
        <?php if(auth()->guard()->guest()): ?>
            <li id="menu-item-707" class="menu-item">
                <a href="<?php echo e(url('/login')); ?>"><span>Login</span></a>
            </li>
            <?php else: ?>
                <?php if(Auth::user()->type == 'customer'): ?>
                <li class="menu-item"><a href="<?php echo e(url('/booking-list')); ?>">My Bookings</a></li>
                <?php elseif(Auth::user()->type == 'driver'): ?>                    
                <li class="menu-item"><a href="<?php echo e(url('/driver/booking-list')); ?>">My Bookings</a></li>
                <?php elseif(Auth::user()->type == 'admin'): ?>
                <li class="menu-item"><a href="<?php echo e(url('/admin')); ?>">Admin Panel</a></li>       
                <?php endif; ?>
                <li class="menu-item"><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
            <?php endif; ?>
    </ul>
  </nav>