<?php $__env->startSection('content'); ?>
<section class="page-header">
    <div class="container">
        <ul class="breadcrumbs">
            <li class="home">
            <a href="/"><?php echo e(config('app.name', 'UK Airport Cabs')); ?></a>
            </li>
            <li class="current">
            // Booking Detail
            </li>
        </ul>
    <h1>Booking Detail</h1>
    </div>
  </section>

   <?php ($detail_css_class = ($booking->status == 'pending')? 'col-md-8 col-lg-8 offset-lg-2 offset-md-2 col-sm-12':'col-md-6 col-lg-6 col-sm-12'); ?>

  <section class="tx-section">
        <div class="container">
            <?php if(Session::has('booking_success')): ?>
            <div class="row">
                <div class="col-md-8 offset-md-2 col-lg-8 offset-lg-2">
                    <div class="alert  alert-success">               
                        <div class="header"><b>Success!</b></div>
                        <p>Your booking created, we will review details and contact you soon! 
                        <br>For any queries contact us at <b><?php echo e(config('settings.phone')); ?></b></p>   
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="<?php echo e($detail_css_class); ?>">

                   <div class="bookings-wrap">
                      <div class="table-responsive">
                          <table class="table color-table primary-table">
                              <thead>
                                  <tr>
                                      <th colspan="2">Bookig Details </th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $booking->showBookingFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td><?php echo e($data['title']); ?></td>
                                      <td><?php echo e($data['value']); ?></td>
                                  </tr>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                          </table>
                      </div>
                   </div>
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12">
                <?php if(is_object($booking->cab)): ?>
                    <div class="bookings-wrap">
                        
                        <div class="table-responsive">
                            <table class="table color-table primary-table">
                                <thead>
                                    <tr>
                                        <th colspan="2">Cab Details </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $booking->showCabFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($title); ?></td>
                                        <td><?php echo e($booking->cab->{$field}); ?></td>
                                    </tr>   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                        <?php endif; ?>

                        <?php if(is_object($booking->driver)): ?>
                        <div class="table-responsive" style="margin-top:10px;">
                            <table class="table color-table primary-table">
                                <thead>
                                    <tr>
                                        <th colspan="2">Driver Details </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $booking->showDriverFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($title); ?></td>
                                        <td><?php echo e($booking->driver->{$field}); ?></td>
                                    </tr>   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>                       
                    </div>
                    <?php endif; ?>
                </div>
            </div> 
            <?php if($booking->status =='pending'): ?>
            <div class="row" style="margin-top:20px; display:none;">
                <div class="col-md-4 col-lg-4 offset-md-4 offset-lg-4 col-sm-12">
                  <button onclick='location.href="<?php echo e(url('/cancel-booking'.$booking->id)); ?>"' class="tx-btn btn btn-lg m-0 pull-right">Cancel booking</button>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>