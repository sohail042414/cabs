<?php
/**
 * This file represends a horizontal zipp like structure.
 */
?>
<div data-vc-full-width="true" data-vc-full-width-init="true" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding"
    style="position: relative; left: -43px; box-sizing: border-box; width: 1286px;">
    <div class="wpb_column vc_column_container vc_col-sm-12">
        <div class="vc_column-inner ">
            <div class="wpb_wrapper">
                <hr class="lg">
            </div>
        </div>
    </div>
</div>