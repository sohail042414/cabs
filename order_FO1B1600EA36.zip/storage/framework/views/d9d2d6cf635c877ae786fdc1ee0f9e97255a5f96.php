<section data-vc-full-width="true" data-vc-full-width-init="true" class="vc_section testimonials-block" style="position: relative; left: -43px; box-sizing: border-box; width: 1286px; padding-left: 43px; padding-right: 43px;">
    <div class="vc_row wpb_row vc_row-fluid">
        <div class="wpb_column vc_column_container vc_col-sm-12">
            <div class="vc_column-inner ">
                <div class="wpb_wrapper">
                    <div class="heading  heading-large align-center" id="like_sc_header_36312132">
                        <h4>Happy Client's</h4>
                        <h2>Testimonials</h2>
                    </div>
                    <div class="swiper-container testimonials-list testimonials-slider row swiper-container-horizontal">
                        <div class="swiper-wrapper" style="transform: translate3d(-780px, 0px, 0px); transition-duration: 1000ms;">
                            <div class="col-md-4 col-sm-6 swiper-slide" style="width: 390px;">
                                <article class="inner matchHeight" style="height: 367px;">
                                    <div class="text">
                                        <p>Nullam orci dui, dictum et magna sollicitudin,
                                            tempor blandit erat. Maecenas suscipit tellus
                                            sit amet augue placerat fringilla a id lacus.
                                            Fusce tincidunt in leo lacinia condimentum.
                                            Maecenas suscipit tellus sit amet augue
                                            placerat fringilla a id lacus.</p>
                                    </div>
                                    <div class="quote">
                                        <span class="fa fa-quote-left"></span>
                                        <div class="name">ANASTASIA STONE</div><img width="102" height="102" src="/images/client-1.jpg"
                                            class="attachment-stargym-test size-stargym-test wp-post-image" alt=""
                                            srcset="/images/client-1.jpg 102w, /images/client-1-100x100.jpg 100w" sizes="(max-width: 102px) 100vw, 102px">
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-sm-6 swiper-slide swiper-slide-prev" style="width: 390px;">
                                <article class="inner matchHeight" style="height: 367px;">
                                    <div class="text">
                                        <p>Quisque sollicitudin feugiat risus, eu posuere
                                            ex euismod eu. Phasellus hendrerit, massa
                                            efficitur dapibus pulvinar, sapien eros sodales
                                            ante, euismod aliquet nulla metus a mauris.</p>
                                    </div>
                                    <div class="quote">
                                        <span class="fa fa-quote-left"></span>
                                        <div class="name">PATRICK JAMES</div><img width="110" height="110" src="/images/client-5.jpg"
                                            class="attachment-stargym-test size-stargym-test wp-post-image" alt=""
                                            srcset="/images/client-5.jpg 110w, /images/client-5-100x100.jpg 100w" sizes="(max-width: 110px) 100vw, 110px">
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-sm-6 swiper-slide swiper-slide-active" style="width: 390px;">
                                <article class="inner matchHeight" style="height: 367px;">
                                    <div class="text">
                                        <p>Suspendisse nec arcu sed nibh lacinia pretium.
                                            Phasellus eros ligula, mattis id rutrum non,
                                            eleifend vitae lacus.
                                        </p>
                                    </div>
                                    <div class="quote">
                                        <span class="fa fa-quote-left"></span>
                                        <div class="name">STEVEN RASHFORD</div><img width="110" height="110" src="/images/client-4.jpg"
                                            class="attachment-stargym-test size-stargym-test wp-post-image" alt=""
                                            srcset="/images/client-4.jpg 110w, /images/client-4-100x100.jpg 100w" sizes="(max-width: 110px) 100vw, 110px">
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-sm-6 swiper-slide swiper-slide-next" style="width: 390px;">
                                <article class="inner matchHeight" style="height: 367px;">
                                    <div class="text">
                                        <p>Nullam orci dui, dictum et magna sollicitudin,
                                            tempor blandit erat. Maecenas suscipit tellus
                                            sit amet augue placerat fringilla a id lacus.
                                            Fusce tincidunt in leo lacinia condimentum.
                                            Maecenas suscipit tellus sit amet augue
                                            placerat fringilla a id lacus. Fusce tincidunt
                                            in leo lacinia condimentum.
                                        </p>
                                    </div>
                                    <div class="quote">
                                        <span class="fa fa-quote-left"></span>
                                        <div class="name">ANASTASIA STONE</div><img width="102" height="102" src="/images/client-1.jpg"
                                            class="attachment-stargym-test size-stargym-test wp-post-image" alt=""
                                            srcset="/images/client-1.jpg 102w, /images/client-1-100x100.jpg 100w" sizes="(max-width: 102px) 100vw, 102px">
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-sm-6 swiper-slide" style="width: 390px;">
                                <article class="inner matchHeight" style="height: 367px;">
                                    <div class="text">
                                        <p>Quisque sollicitudin feugiat risus, eu posuere
                                            ex euismod eu. Phasellus hendrerit, massa
                                            efficitur dapibus pulvinar, sapien eros sodales
                                            ante, euismod aliquet nulla metus a mauris.</p>
                                    </div>
                                    <div class="quote">
                                        <span class="fa fa-quote-left"></span>
                                        <div class="name">PATRICK JAMES</div><img width="110" height="110" src="/images/client-5.jpg"
                                            class="attachment-stargym-test size-stargym-test wp-post-image" alt=""
                                            srcset="/images/client-5.jpg 110w, /images/client-5-100x100.jpg 100w" sizes="(max-width: 110px) 100vw, 110px">
                                    </div>
                                </article>
                            </div>
                            <div class="col-md-4 col-sm-6 swiper-slide" style="width: 390px;">
                                <article class="inner matchHeight" style="height: 367px;">
                                    <div class="text">
                                        <p>Nullam orci dui, dictum et magna sollicitudin,
                                            tempor blandit erat. Maecenas suscipit tellus
                                            sit amet augue placerat fringilla a id lacus.
                                            Fusce tincidunt in leo lacinia condimentum.
                                            Maecenas suscipit tellus sit amet augue
                                            placerat fringilla a id lacus. Fusce tincidunt
                                            in leo lacinia condimentum.</p>
                                    </div>
                                    <div class="quote">
                                        <span class="fa fa-quote-left"></span>
                                        <div class="name">ANASTASIA STONE</div><img width="102" height="102" src="/images/client-1.jpg"
                                            class="attachment-stargym-test size-stargym-test wp-post-image" alt=""
                                            srcset="/images/client-1.jpg 102w, /images/client-1-100x100.jpg 100w" sizes="(max-width: 102px) 100vw, 102px">
                                    </div>
                                </article>
                            </div>
                        </div>
                        <div class="arrows" style="display:none;">
                            <a href="#" class="arrow-left fa fa-caret-left"></a>
                            <a href="#" class="arrow-right fa fa-caret-right"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>