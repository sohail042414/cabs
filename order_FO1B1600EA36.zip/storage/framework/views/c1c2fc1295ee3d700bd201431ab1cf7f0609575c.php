<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-2 col-lg-2">
        <?php echo $__env->make('admin.pages.airports.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-10 col-lg-10">
        <div class="card">
            <div class="card-header">Airports</div>
            <div class="-body">
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Latitude</th>
                            <th scope="col">Longitude</th>
                            <th colspan="2" scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($airport->id); ?></td>
                            <td><?php echo e($airport->name); ?></td>
                            <td><?php echo e($airport->lat); ?></td>
                            <td><?php echo e($airport->lng); ?></td>
                            <td>
                                <a class="btn btn-primary" href="/admin/airports/<?php echo e($airport->id); ?>/edit/">Edit</a>
                            </td>
                            <td>
                                <a class="btn btn-danger" href="/admin/airports/delete/<?php echo e($airport->id); ?>">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="5">
                                <?php echo e($list->links("pagination::bootstrap-4")); ?>

                            </td>
                        </tr>
                    </tbody>

                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>