<?php $__env->startComponent('mail::message'); ?>
# Booking Request Received

We have received you request for taxi, we are reviewing booking details, will confirm you booking soon!
<?php $__currentLoopData = $booking->showBookingFields(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($data['title']); ?> : <?php echo e($data['value']); ?>       
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
Click on the the link below and check details.
<?php $__env->startComponent('mail::button', ['url' => url("/booking-detail/{$booking->id}")]); ?>
View Booking Detail
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
