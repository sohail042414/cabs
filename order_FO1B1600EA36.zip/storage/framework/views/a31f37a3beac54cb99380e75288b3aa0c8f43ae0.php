<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="col-md-6 offset-md-3">
    <div class="login-wrapper">
        <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo e(csrf_field()); ?>

            <div class="login-header">
            <h1 class="lo-title">Registration</h1>
            <span class="lo-sub">It's free and will remain!</span>
            </div>
            <div class="login-txt-block">
                <label>Full Name</label>
                <input type="text" name="name" placeholder="John Doe" value="<?php echo e(old('name')); ?>" />
                <?php if($errors->has('name')): ?>
                <span class="error-message">                
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="login-txt-block">
                <label>Email </label>
                <input type="email" name="email" placeholder="john@example.com" value="<?php echo e(old('email')); ?>" />
                <?php if($errors->has('email')): ?>
                <span class="error-message">  
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="login-txt-block">
                <label>Password</label>
                <input type="password" name="password" placeholder="*****" value="<?php echo e(old('password')); ?>" />
                <?php if($errors->has('password')): ?>
                <span class="error-message">  
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div class="login-txt-block">
                <label>Confirm Password</label>
                <input type="password" name="password_confirmation" placeholder="*****" value="<?php echo e(old('password_confirmation')); ?>" />
                <?php if($errors->has('password')): ?>
               <span class="error-message">  
                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            
            <div class="login-txt-block">
                <button class="login-btn"> Submit</button>
                <a href="/login" class="forgot">Login Here</a>
            </div>
        </form>
    </div>
    
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.auth_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>