<div data-vc-full-width="true" data-vc-full-width-init="true" class="vc_row wpb_row vc_row-fluid banners-block" style="position: relative; left: -43px; box-sizing: border-box; width: 1286px; padding-left: 43px; padding-right: 43px;">
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner ">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_left">

                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper   vc_box_border_grey">
                            <img width="600" height="238" src="/images/banner-1-4.png" class="vc_single_image-img attachment-full"
                                alt="" srcset="/images/banner-1-4.png 600w, /images/banner-1-4-300x119.png 300w" sizes="(max-width: 600px) 100vw, 600px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-6">
        <div class="vc_column-inner ">
            <div class="wpb_wrapper">
                <div class="wpb_single_image wpb_content_element vc_align_left">

                    <figure class="wpb_wrapper vc_figure">
                        <div class="vc_single_image-wrapper   vc_box_border_grey"><img width="600" height="238" src="/images/banner-2-2.png"
                                class="vc_single_image-img attachment-full" alt="" srcset="/images/banner-2-2.png 600w, /images/banner-2-2-300x119.png 300w"
                                sizes="(max-width: 600px) 100vw, 600px"></div>
                    </figure>
                </div>
            </div>
        </div>
    </div>
</div>