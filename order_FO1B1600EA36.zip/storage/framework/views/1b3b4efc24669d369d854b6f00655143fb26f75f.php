<?php echo $__env->make('admin.common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php ($method = ($action =='create') ? 'POST' : 'PUT'); ?>
<?php ($action_url = ($action =='create') ? '/admin/terms' : '/admin/terms/'.$term->id); ?>


<form method="POST" action="<?php echo e($action_url); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field($method)); ?>

    <div class="form-group">
        <label for="sort_order">Sort Order</label>
        <input name="sort_order" type="text" value="<?php echo e(old('sort_order',$term->sort_order)); ?>" class="form-control" id="sort_order">
        <small id="emailHelp" class="form-text text-muted">It will be used to display question in FAQs page, starting
            from lowest number. </small>
    </div>

    <div class="form-group">
        <label for="title">Title</label>
        <input type="text" name="title" value="<?php echo e(old('title',$term->title)); ?>" id="title" class="form-control">
    </div>
    <div class="form-group">
        <label for="text">Text(Details)</label>
        <textarea name="text" id="text" rows="10" style="resize:x;" class="form-control"><?php echo e(old('text',$term->text)); ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>