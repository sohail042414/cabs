<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('GOOGLE_API_KEY')); ?>&libraries=places">
</script>
<script src="<?php echo e(asset('js/jquery.geocomplete.min.js')); ?>">
</script>