<?php echo $__env->make('admin.common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php ($method = ($action =='create') ? 'POST' : 'PUT'); ?>
<?php ($action_url = ($action =='create') ? '/admin/settings' : '/admin/settings/'.$setting->id); ?>


<form method="POST" action="<?php echo e($action_url); ?>">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field($method)); ?>

    <div class="form-group">
        <label for="title">Title</label>
        <input name="title" type="text" value="<?php echo e(old('title',$setting->title)); ?>" class="form-control" id="title">
        <small id="titleHelp" class="form-text text-muted">Used for display.</small>
    </div>

    <div class="form-group">
        <label for="key">Key</label>
        <?php if($action =='create'): ?>
        <input type="text" name="key" value="<?php echo e(old('key',$setting->key)); ?>" id="key" class="form-control">
        <?php else: ?>
        <input type="text" name="key" value="<?php echo e($setting->key); ?>" id="key" class="form-control" readonly>        
        <?php endif; ?>
        <small id="keyHelp" class="form-text text-muted">Used in programming, not changable</small>
    </div>
    <div class="form-group">
        <label for="value">Value</label>
        <input type="text" name="value" id="value"  class="form-control" value="<?php echo e(old('value',$setting->value)); ?>" >
        <small id="keyHelp" class="form-text text-muted">For boolean keys set 0 for false, 1 for true!, anything other then 0 will be considered true.</small>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>