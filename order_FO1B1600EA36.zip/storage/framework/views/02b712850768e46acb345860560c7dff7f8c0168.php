<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('jquery-ui/jquery-1.11.1.min.js')); ?>" defer></script>  
<script src="<?php echo e(asset('jquery-ui/jquery-ui.min.js')); ?>" defer></script>  
<script src="<?php echo e(asset('jquery-ui/jquery-ui-timepicker-addon.js')); ?>" defer></script>  

<link href="<?php echo e(asset('jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('jquery-ui/jquery-ui-timepicker-addon.css')); ?>" rel="stylesheet">
<?php echo $__env->make('geocode', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<ul class="cb-slideshow">
    <li><span>Image 01</span><div></div></li>
    <li><span>Image 02</span><div></div></li>
    <li><span>Image 03</span><div></div></li>
    <li><span>Image 04</span><div></div></li>
    <li><span>Image 05</span><div></div></li>
    <li><span>Image 06</span><div></div></li>
  </ul>
  
<section class="homepage-1 top-spacing bottom-spacing">

    <div class="container">
    <div class="row">
        <div class="col-md-8 col-lg-8 col-sm-12">
        <div class="search-block-box gray">        
            <?php echo $__env->make('front.common.taxi_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>        
    </div>    
</div>
</div>
</section>
<?php echo $__env->make('front.common.section_info', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('front.common.section_tarrif', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('front.common.section_clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>