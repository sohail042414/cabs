<?php

namespace App\Models;

use App\Models\BaseModel;

class Faq extends BaseModel
{
    //
}