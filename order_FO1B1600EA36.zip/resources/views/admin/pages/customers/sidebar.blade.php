<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/customers">All Customers</a>
    </li>
</ul>