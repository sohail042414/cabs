<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/services">Services List</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/services/create">Create Service</a>
    </li>
</ul>