<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/cabs">Cabs List</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/cabs/create">Create Cab</a>
    </li>
</ul>