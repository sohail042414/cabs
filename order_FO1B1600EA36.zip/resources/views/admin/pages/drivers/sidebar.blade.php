<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/drivers">All Drivers</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/drivers/create">Create Driver</a>
    </li>
</ul>