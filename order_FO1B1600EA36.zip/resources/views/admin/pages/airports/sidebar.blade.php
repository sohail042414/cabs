<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/airports">All Airports</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/airports/create">Create Airport</a>
    </li>
</ul>