<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/terms">All Terms</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/terms/create">Create Term</a>
    </li>
</ul>