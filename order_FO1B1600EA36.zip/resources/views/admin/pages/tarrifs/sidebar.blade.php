<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/tarrifs">Tarrif List</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/tarrifs/create">Create Tarrif</a>
    </li>
</ul>