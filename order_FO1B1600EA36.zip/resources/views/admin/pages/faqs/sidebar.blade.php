<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/faqs">All FAQs</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/faqs/create">Create FAQ</a>
    </li>
</ul>