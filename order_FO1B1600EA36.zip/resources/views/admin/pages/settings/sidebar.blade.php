<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/settings">All Settings</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/settings/create">Create Setting</a>
    </li>
</ul>