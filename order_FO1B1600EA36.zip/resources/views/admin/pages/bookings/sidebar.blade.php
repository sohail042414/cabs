<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="/admin/bookings">All Bookings</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="/admin/bookings/create">Create Booking</a>
    </li>
</ul>