<hr class="lg">
<section class="tx-section bg">
    <div class="container">
      <div class="tx-heading center">
        <h4>HAPPY CLIENT'S</h4>
        <h2>TESTIMONIALS</h2>
      </div>

      <div class="testimonials-wrap">
        <div class="row">
          <div class="col-md-4">
            <div class="testimonial-block">
              <p>Nullam orci dui, dictum et magna sollicitudin, tempor blandit erat. Maecenas suscipit tellus sit amet
                augue placerat fringilla a id lacus. Fusce tincidunt in leo lacinia condimentum. Maecenas suscipit
                tellus sit amet augue placerat fringilla a id lacus. Fusce tincidunt in leo lacinia condimentum.</p>
              <div class="quote">
                <span class="fa fa-quote-left"></span>
                <div class="name">ANASTASIA STONE</div>
                <img width="102" height="102" src="http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-1.jpg"
                  class="attachment-stargym-test size-stargym-test wp-post-image" alt="" srcset="http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-1.jpg 102w, http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-1-100x100.jpg 100w">
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="testimonial-block">
              <p>Suspendisse nec arcu sed nibh lacinia pretium. Phasellus eros ligula, mattis id rutrum non, eleifend
                vitae lacus.</p>
              <div class="quote">
                <span class="fa fa-quote-left"></span>
                <div class="name">PATRICK JAMES</div>
                <img width="110" height="110" src="http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-5.jpg"
                  class="attachment-stargym-test size-stargym-test wp-post-image" alt="" srcset="http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-5.jpg 110w, http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-5-100x100.jpg 100w">
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="testimonial-block">
              <p>Nullam orci dui, dictum et magna sollicitudin, tempor blandit erat. Maecenas suscipit tellus sit amet
                augue placerat fringilla a id lacus. Fusce tincidunt in leo lacinia condimentum. Maecenas suscipit
                tellus sit amet augue placerat fringilla a id lacus. Fusce tincidunt in leo lacinia condimentum.</p>
              <div class="quote">
                <span class="fa fa-quote-left"></span>
                <div class="name">ANASTASIA STONE</div>
                <img width="102" height="102" src="http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-1.jpg"
                  class="attachment-stargym-test size-stargym-test wp-post-image" alt="" srcset="http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-1.jpg 102w, http://taxipark.like-themes.com/wp-content/uploads/2017/05/client-1-100x100.jpg 100w">
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>
  </section>