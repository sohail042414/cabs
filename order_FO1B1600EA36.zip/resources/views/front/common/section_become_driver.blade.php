
  <section class="tx-section driver-wrap">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="tx-heading tx-z">
            <h4>FOR DRIVERS</h4>
            <h2>DO YOU WANT TO EARN WITH US?</h2>
            <p>Quisque sollicitudin feugiat risus, eu posuere ex euismod eu. Phasellus hendrerit, massa efficitur
              dapibus pulvinar, sapien eros sodales ante, euismod aliquet nulla metus a mauris.</p>
          </div>

          <div class="tx-list-driver tx-z">
            <ul class="tx-list">
              <li>Luxury cars</li>
              <li>No fee</li>
              <li>Weekly payment</li>
              <li>Fixed price</li>
              <li>Good application</li>
              <li>Stable orders</li>
            </ul>
          </div>

          <div class="btn-wrap align-left">
            <a href="" class="tx-btn btn btn-lg align-left">Become a Driver</a>
          </div>


        </div>
      </div>
    </div>

    <div class="tx-car">
      <img src="theme/img/car-big-side.png" alt="car big" />
    </div>
  </section>