<section class="our-partners-wrap">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="tx-heading">
              <h4>OUR PARTNERS</h4>
              <h2>AND CLIENTS</h2>
            </div>
          </div>
          <div class="col-md-8">
            <div class="row mt-3">
              <div class="col-6 col-sm-6 col-md-3">
                <div class="cl-img">
                  <img src="/theme/img/partner-1.png" alt="img">
                </div>
              </div>
              <div class="col-6 col-sm-6 col-md-3">
                <div class="cl-img">
                  <img src="/theme/img/partner-2.png" alt="img">
                </div>
              </div>
              <div class=" col-6 col-sm-6 col-md-3">
                <div class="cl-img">
                  <img src="/theme/img/partner-3.png" alt="img">
                </div>
              </div>
              <div class="col-6 col-sm-6 col-md-3">
                <div class="cl-img">
                  <img src="/theme/img/partner-4.png" alt="img">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
</section>
