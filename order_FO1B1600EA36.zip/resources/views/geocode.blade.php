<script src="https://maps.googleapis.com/maps/api/js?key={{config('settings.google_api_key')}}&libraries=places">
</script>
<script src="{{ asset('js/jquery.geocomplete.min.js') }}">
</script>